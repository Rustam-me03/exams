const router = require("express").Router();
const adminMiddleware = require("../police_middleware/admin_police");
const selfPolice = require("../police_middleware/self_police");

const {
  addAdmin,
  loginAdmin,
  logoutAdmin,
  getAdmins,
  deleteAdminById,
  updateAdminById,
  getAdminById,
} = require("../controllers/admin.controller");

router.post("/create", addAdmin);
router.post("/login", loginAdmin);
router.post("/logout", selfPolice, logoutAdmin);

router.get("/all",  getAdmins);
router.get("/id:id", selfPolice, getAdminById);

router.put("/update:id", selfPolice, updateAdminById);
router.delete("/delete:id", selfPolice, deleteAdminById);

module.exports = router;
