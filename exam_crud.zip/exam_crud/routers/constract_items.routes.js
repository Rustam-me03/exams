const router = require("express").Router();

const { updateContract } = require("../controllers/contract.controller");
const {
  createContractItem,
  getContractItems,
  getContractItemById,
  updateContractItem,
  deleteContractItem,
} = require("../controllers/contract_items.controller");

router.post("/create", createContractItem);

router.get("/all", getContractItems);
router.get("/id/:id", getContractItemById);
router.put("/update/:id", updateContract);

router.delete("/delete/:id", deleteContractItem);

module.exports = router;
