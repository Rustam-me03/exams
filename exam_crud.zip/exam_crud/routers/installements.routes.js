const { getAdminById } = require("../controllers/admin.controller");
const {
  createInstallment,
  getAllInstallments,
  getInstallmentById,
  updateInstallment,
  deleteInstallment,
} = require("../controllers/installements.controller");

const router = require("express").Router();

router.post("/create", createInstallment);

router.get("/all", getAllInstallments);
router.get("/id:id", getAdminById);
router.put("/update:id", updateInstallment);

router.delete("/delete:id", deleteInstallment);

module.exports = router;
