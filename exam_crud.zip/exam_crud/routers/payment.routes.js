const {
  createPayment,
  getPayments,
  getPaymentById,
  updatePayment,
  deletePayment,
} = require("../controllers/payment.controller");

const router = require("express").Router();

router.post("/create", createPayment);

router.get("/all", getPayments);
router.get("/id:id", getPaymentById);
router.put("/update:id", updatePayment);

router.delete("/delete:id", deletePayment);

module.exports = router;
