const {
  createProduct,
  getProducts,
  getProductById,
  updateProduct,
  deleteProduct,
} = require("../controllers/product.controller");

const router = require("express").Router();

router.post("/create", createProduct);

router.get("/all", getProducts);
router.get("/id:id", getProductById);
router.put("/update:id", updateProduct);

router.delete("/delete:id", deleteProduct);

module.exports = router;
