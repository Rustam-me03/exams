const router = require("express").Router();
const {
  createImg,
  getImgs,
  getImgById,
  updateImg,
  deleteImg,
} = require("../controllers/images.controller");

router.post("/create", createImg);

router.get("/all", getImgs);
router.get("/id:id", getImgById);
router.put("/update:id", updateImg);

router.delete("/delete:id", deleteImg);

module.exports = router;
