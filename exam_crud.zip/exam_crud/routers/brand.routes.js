const router = require("express").Router();
const {
  addBrand,
  getBrands,
  getBrandById,
  updateBrandById,
  deleteBrandById,
} = require("../controllers/brand.controller");

router.post("/create", addBrand);

router.get("/all", getBrands);
router.get("/id:id", getBrandById);
router.put("/update:id", updateBrandById);

router.delete("/delete:id", deleteBrandById);

module.exports = router;
