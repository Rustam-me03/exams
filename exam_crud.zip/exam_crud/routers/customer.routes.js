const router = require("express").Router();
const customerPolice = require("../police_middleware/customer_police");
const selfPolice = require("../police_middleware/customer_self_police");

const {
  addCustomer,
  loginCustomer,
  logoutCustomer,
  getCustomers,
  deleteCustomerById,
  updateCustomerById,
  getCustomerById,
} = require("../controllers/customer.controller");

router.post("/create", addCustomer);
router.post("/login", loginCustomer);
router.post("/logout", logoutCustomer);
router.get("/all",  getCustomers);
router.get("/get/:id", selfPolice, getCustomerById);
router.put("/update/:id", selfPolice, updateCustomerById);
// router.delete("/delete/:id",selfPolice, customerPolice, deleteCustomerById);

module.exports = router;
