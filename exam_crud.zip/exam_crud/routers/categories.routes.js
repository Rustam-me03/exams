const router = require("express").Router();

const {
  createContract,
  getContracts,
  getContractById,
  updateContract,
  deleteContract,
} = require("../controllers/contract.controller");

router.post("/create", createContract);

router.get("/all", getContracts);
router.get("/id/:id", getContractById);
router.put("/update/:id", updateContract);

router.delete("/delete/:id", deleteContract);

module.exports = router;
