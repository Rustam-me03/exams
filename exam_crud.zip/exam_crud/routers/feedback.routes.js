const router = require("express").Router();

const {
  createFeedback,
  getFeedbacks,
  getFeedbackById,
  updateFeedback,
  deleteFeedback,
} = require("../controllers/feedback.controller");

router.post("/create", createFeedback);

router.get("/all", getFeedbacks);
router.get("/id/:id", getFeedbackById);
router.put("/update/:id", updateFeedback);

router.delete("/delete/:id", deleteFeedback);

module.exports = router;
