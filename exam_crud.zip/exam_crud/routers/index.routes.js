const express = require('express');
const adminRoutes = require("./admin.routes")
const brandRoutes = require("./brand.routes")
const categoriesRoutes = require("./categories.routes")
const contracItemtRoutes = require("./constract_items.routes")
const constractRoutes = require("./contract.routes")
const customerRoutes = require("./customer.routes")
const feedbackRoutes = require("./feedback.routes")
const imgRoutes = require("./img.routes")
const installementsRoutes = require("./installements.routes")
const paymentRoutes = require("./payment.routes")
const productRoutes = require("./product.routes")

const router = express.Router();

router.use('/admin', adminRoutes);
router.use('/brand', brandRoutes);
router.use('/categories', categoriesRoutes);
router.use('/itmes', contracItemtRoutes);
router.use('/contract', constractRoutes);
router.use('/customer', customerRoutes);
router.use('/feedback', feedbackRoutes);
router.use('/img', imgRoutes);
router.use('/installements', installementsRoutes);
router.use('/pyment', paymentRoutes);
router.use("/product", productRoutes)

module.exports = router;
