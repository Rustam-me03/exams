const Joi = require("joi");

const validateImage = Joi.object({
  name: Joi.string().min(3).max(255).required(),
  path: Joi.string().min(3).required(),
  size: Joi.number().min(1).required(),
  type: Joi.string().valid('jpeg', 'png', 'gif', 'bmp', 'webp').required(), 
});

const validateIdParam = Joi.object({
  id: Joi.number().integer().positive().required(),
});

module.exports = {
  validateImage,
  validateIdParam,
};
