const Joi = require("joi");

const contractSchema = Joi.object({
  customer_id: Joi.number().integer().required().messages({
    "number.base": "Customer ID must be an integer",
    "any.required": "Customer ID is required",
  }),
  admin_id: Joi.number().integer().required().messages({
    "number.base": "Admin ID must be an integer",
    "any.required": "Admin ID is required",
  }),
  start_date: Joi.date().required().messages({
    "date.base": "Start date must be a valid date",
    "any.required": "Start date is required",
  }),
  down_payment: Joi.number().precision(2).required().messages({
    "number.base": "Down payment must be a decimal",
    "any.required": "Down payment is required",
  }),
  status: Joi.string().valid("active", "inactive").required().messages({
    "any.only": "Status must be either active or inactive",
    "any.required": "Status is required",
  }),
  total_amount: Joi.number().precision(2).required().messages({
    "number.base": "Total amount must be a decimal",
    "any.required": "Total amount is required",
  }),
  installments_id: Joi.number().integer().required().messages({
    "number.base": "Installments ID must be an integer",
    "any.required": "Installments ID is required",
  }),
});

const validateContract = (req, res, next) => {
  const { error } = contractSchema.validate(req.body, { abortEarly: false });
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((detail) => detail.message) });
  }
  next();
};

const idSchema = Joi.object({
  id: Joi.number().integer().required().messages({
    "number.base": "ID must be an integer",
    "any.required": "ID is required",
  }),
});

const validateIdParam = (req, res, next) => {
  const { error } = idSchema.validate(req.params, { abortEarly: false });
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((detail) => detail.message) });
  }
  next();
};

module.exports = {
  validateContract,
  validateIdParam,
};
