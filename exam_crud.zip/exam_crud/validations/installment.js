const Joi = require('joi');

const validateInstallment = (data) => {
  const schema = Joi.object({
    DurationMonths: Joi.number().valid(6, 12, 18).required().messages({
      'any.only': 'DurationMonths must be one of the following values: 6, 12, 18',
      'number.base': 'DurationMonths must be a number',
      'any.required': 'DurationMonths is required'
    }),
    Description: Joi.string().min(3).max(255).required().messages({
      'string.base': 'Description must be a string',
      'string.min': 'Description must be at least 3 characters long',
      'string.max': 'Description must not exceed 255 characters',
      'any.required': 'Description is required'
    })
  });
  return schema.validate(data, { abortEarly: false });
};

const validateIdParam = (params) => {
  const schema = Joi.object({
    id: Joi.string().hex().length(24).required().messages({
      'string.base': 'ID must be a string',
      'string.hex': 'ID must be a valid hex string',
      'string.length': 'ID must be 24 characters long',
      'any.required': 'ID is required'
    })
  });
  return schema.validate(params, { abortEarly: false });
};

module.exports = {
  validateInstallment,
  validateIdParam
};
