const Joi = require("joi");

const adminSchema = Joi.object({
  name: Joi.string().min(3).required(),
  surename: Joi.string().min(3).required(),
  username: Joi.string().min(3).required(),
  email: Joi.string().email().required(),
  phone_number: Joi.string()
    .pattern(/^\+?[1-9]\d{1,14}$/)
    .required(),
  password: Joi.string().min(6).required(),
  isActive: Joi.boolean().default(true),
  isCreator: Joi.boolean().default(false),
});

const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
});

const updateAdminSchema = Joi.object({
  name: Joi.string().min(3).optional(),
  surename: Joi.string().min(3).optional(),
  username: Joi.string().min(3).optional(),
  email: Joi.string().email().optional(),
  phone_number: Joi.string()
    .pattern(/^\+?[1-9]\d{1,14}$/)
    .optional(),
  password: Joi.string().min(6).optional(),
  isActive: Joi.boolean().optional(),
  isCreator: Joi.boolean().optional(),
});

module.exports = {
  adminSchema,
  loginSchema,
  updateAdminSchema,
};
