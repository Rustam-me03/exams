const Joi = require("joi");

const validateCategory = (data) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(255).required(),
    description: Joi.string().allow(null, "").max(500),
  });
  return schema.validate(data);
};

const validateIdParam = (params) => {
  const schema = Joi.object({
    id: Joi.number().integer().positive().required(),
  });
  return schema.validate(params);
};

module.exports = {
  validateCategory,
  validateIdParam,
};
