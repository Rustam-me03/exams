const Joi = require("joi");

exports.customerValidation = (data) => {
  const customerValidation = Joi.object({
    id: Joi.number().integer().positive(),
    name: Joi.string().max(255).required(),
    surname: Joi.string().max(255).optional().allow(null, ""),
    email: Joi.string().email().max(255).required(),
    phone: Joi.string()
      .pattern(/^[0-9]{2}-[0-9]{3}-[0-9]{2}-[0-9]{2}$/)
      .optional()
      .allow(null, ""),
    password: Joi.string().min(6).required(),
    address: Joi.string().max(255).optional().allow(null, ""),
    passport_number: Joi.string().length(9).required().messages({
      "string.length": "Passport number must be exactly 9 characters.",
    }),
    refresh_token: Joi.string().optional().allow(null, ""),
    verification: Joi.boolean().default(false),
    created_at: Joi.date().optional(),
    updated_at: Joi.date().optional(),
  });

  return customerValidation.validate(data, { abortEarly: false });
};
