const Joi = require('joi');

const feedbackSchema = Joi.object({
  user_id: Joi.number().integer().required().messages({
    'number.base': 'User ID must be an integer',
    'any.required': 'User ID is required'
  }),
  message: Joi.string().required().messages({
    'string.base': 'Message must be a string',
    'any.required': 'Message is required'
  }),
  rating: Joi.number().integer().min(1).max(5).required().messages({
    'number.base': 'Rating must be an integer',
    'number.min': 'Rating must be at least 1',
    'number.max': 'Rating must be at most 5',
    'any.required': 'Rating is required'
  })
});

const validateFeedback = (req, res, next) => {
  const { error } = feedbackSchema.validate(req.body, { abortEarly: false });
  if (error) {
    return res.status(400).json({ errors: error.details.map(detail => detail.message) });
  }
  next();
};

const idSchema = Joi.object({
  id: Joi.number().integer().required().messages({
    'number.base': 'ID must be an integer',
    'any.required': 'ID is required'
  })
});

const validateIdParam = (req, res, next) => {
  const { error } = idSchema.validate(req.params, { abortEarly: false });
  if (error) {
    return res.status(400).json({ errors: error.details.map(detail => detail.message) });
  }
  next();
};

module.exports = {
  validateFeedback,
  validateIdParam
};