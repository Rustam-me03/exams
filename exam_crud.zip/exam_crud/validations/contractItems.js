const Joi = require("joi");

const contractSchema = Joi.object({
  customer_id: Joi.number().integer().required().messages({
    "number.base": "Customer ID must be an integer",
    "any.required": "Customer ID is required",
  }),
  admin_id: Joi.number().integer().required().messages({
    "number.base": "Admin ID must be an integer",
    "any.required": "Admin ID is required",
  }),
  start_date: Joi.date().required().messages({
    "date.base": "Start date must be a valid date",
    "any.required": "Start date is required",
  }),
  down_payment: Joi.number().min(0).required().messages({
    "number.base": "Down payment must be a number",
    "number.min": "Down payment cannot be negative",
    "any.required": "Down payment is required",
  }),
  status: Joi.string().required().messages({
    "string.base": "Status must be a string",
    "any.required": "Status is required",
  }),
  total_amount: Joi.number().min(0).required().messages({
    "number.base": "Total amount must be a number",
    "number.min": "Total amount cannot be negative",
    "any.required": "Total amount is required",
  }),
  installments_id: Joi.number().integer().optional().messages({
    "number.base": "Installments ID must be an integer",
  }),
});

const idSchema = Joi.object({
  id: Joi.number().integer().required().messages({
    "number.base": "ID must be an integer",
    "any.required": "ID is required",
  }),
});

const validateContract = (req) => contractSchema.validate(req.body, { abortEarly: false });

const validateIdParam = (req) => idSchema.validate(req.params, { abortEarly: false });

module.exports = {
  validateContract,
  validateIdParam,
};
