const Joi = require("joi");

const validateProduct = (product) => {
  const schema = Joi.object({
    ProductName: Joi.string().min(3).max(30).required(),
    Description: Joi.string().min(5).max(100).required(),
    Price: Joi.number().positive().required(),
    StockQuantity: Joi.number().integer().positive().required(),
    CategoryID: Joi.number().integer().positive().optional(),
    Brand_id: Joi.number().integer().positive().optional(),
  });

  return schema.validate(product);
};

const validateIdParam = (params) => {
  const schema = Joi.object({
    id: Joi.number().integer().positive().required(),
  });

  return schema.validate(params);
};

module.exports = { validateProduct, validateIdParam };
