const Joi = require("joi");

const paymentSchema = Joi.object({
  OrderID: Joi.number().integer().required().messages({
    "number.base": "OrderID must be an integer",
    "any.required": "OrderID is required",
  }),
  PaymentDate: Joi.date().required().messages({
    "date.base": "PaymentDate must be a valid date",
    "any.required": "PaymentDate is required",
  }),
  PaymentAmount: Joi.number().precision(2).required().messages({
    "number.base": "PaymentAmount must be a number",
    "number.precision": "PaymentAmount must have at most 2 decimal places",
    "any.required": "PaymentAmount is required",
  }),
  PaymentMethod: Joi.string().required().messages({
    "string.base": "PaymentMethod must be a string",
    "any.required": "PaymentMethod is required",
  }),
  status: Joi.string().valid("paid", "pending").required().messages({
    "any.only": "Status must be either 'paid' or 'pending'",
    "any.required": "Status is required",
  }),
});

const idSchema = Joi.object({
  id: Joi.number().integer().required().messages({
    "number.base": "ID must be an integer",
    "any.required": "ID is required",
  }),
});

const validatePayment = (req) =>
  paymentSchema.validate(req.body, { abortEarly: false });

const validateIdParam = (req) =>
  idSchema.validate(req.params, { abortEarly: false });

module.exports = {
  validatePayment,
  validateIdParam,
};
