const Joi = require("joi");

const validateAddBrand = (data) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(50).required().messages({
      "string.base": "Name must be a string.",
      "string.empty": "Name is required.",
      "string.min": "Name must have at least 2 characters.",
      "string.max": "Name must have at most 50 characters.",
      "any.required": "Name is required.",
    }),
  });

  return schema.validate(data);
};

const validateUpdateBrand = (data) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(50).optional().messages({
      "string.base": "Name must be a string.",
      "string.empty": "Name cannot be empty.",
      "string.min": "Name must have at least 2 characters.",
      "string.max": "Name must have at most 50 characters.",
    }),
  });

  return schema.validate(data);
};

const validateIdParam = (data) => {
  const schema = Joi.object({
    id: Joi.number().integer().positive().required().messages({
      "number.base": "ID must be a number.",
      "number.integer": "ID must be an integer.",
      "number.positive": "ID must be a positive number.",
      "any.required": "ID is required.",
    }),
  });

  return schema.validate(data);
};

module.exports = {
  validateAddBrand,
  validateUpdateBrand,
  validateIdParam,
};
