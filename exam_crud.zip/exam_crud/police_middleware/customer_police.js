const { to } = require("../helpers/to_promise");
const customerJwt = require("../services/jwt_service");
const Customer = require("../models/customer");

module.exports.customerRefreshMiddleware = async function (req, res, next) {
  try {
    const { customer_refreshToken } = req.cookies;

    if (!customer_refreshToken) {
      return res
        .status(403)
        .send({ message: "Unauthorized: No refresh token provided" });
    }

    const [error, decodedToken] = await to(
      customerJwt.verifyRefreshToken(customer_refreshToken)
    );

    if (error) {
      return res
        .status(403)
        .send({ message: "Unauthorized: " + error.message });
    }

    const customer = await Customer.findByPk(decodedToken.id);

    if (!customer || customer.refresh_token !== customer_refreshToken) {
      return res.status(403).send({
        message: "Unauthorized: Invalid refresh token",
      });
    }

    req.customer = decodedToken;
    next();
  } catch (error) {
    return res.status(403).send({ message: "Unauthorized: " + error.message });
  }
};

module.exports.customerAccessMiddleware = async function (req, res, next) {
  try {
    const authorization = req.headers.authorization;

    if (!authorization) {
      return res
        .status(403)
        .send({ message: "Unauthorized: No access token provided" });
    }

    const [bearer, token] = authorization.split(" ");
    if (bearer !== "Bearer" || !token) {
      return res
        .status(403)
        .send({ message: "Unauthorized: Invalid token format" });
    }

    const [error, decodedToken] = await to(
      customerJwt.verifyaccessToken(token)
    );

    if (error) {
      return res
        .status(403)
        .send({ message: "Unauthorized: " + error.message });
    }

    const customer = await Customer.findByPk(decodedToken.id);

    if (!customer) {
      return res
        .status(403)
        .send({ message: "Unauthorized: Customer not found" });
    }

    req.customer = decodedToken;
    next();
  } catch (error) {
    return res.status(403).send({ message: "Unauthorized: " + error.message });
  }
};
