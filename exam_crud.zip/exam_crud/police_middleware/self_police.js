const { to } = require("../helpers/to_promise");
const Admin = require("../models/admin");
const adminJwt = require("../services/jwt_service");

module.exports = async function selfPolice(req, res, next) {
  try {
    const authorization = req.headers.authorization;

    if (!authorization) {
      return res
        .status(401)
        .send({ message: "Unauthorized: No token provided" });
    }

    const [bearer, token] = authorization.split(" ");

    if (bearer !== "Bearer" || !token) {
      return res
        .status(401)
        .send({ message: "Unauthorized: Invalid token format" });
    }

    const [error, decodedToken] = await to(adminJwt.verifyaccessToken(token));
    if (error) {
      return res
        .status(401)
        .send({ message: "Unauthorized: " + error.message });
    }

    const adminIdFromToken = decodedToken.id;

    if (!req.params.id || req.params.id !== String(adminIdFromToken)) {
      return res.status(403).send({
        message: "Forbidden: You are not allowed to perform this action",
      });
    }

    req.admin = decodedToken;
    next();
  } catch (error) {
    return res
      .status(500)
      .send({ message: "Internal Server Error: " + error.message });
  }
};

module.exports = async function logout(req, res) {
  try {
    const authorization = req.headers.authorization;

    if (!authorization) {
      return res
        .status(401)
        .send({ message: "Unauthorized: No token provided" });
    }

    const [bearer, token] = authorization.split(" ");

    if (bearer !== "Bearer" || !token) {
      return res
        .status(401)
        .send({ message: "Unauthorized: Invalid token format" });
    }

    const [error, decodedToken] = await to(adminJwt.verifyaccessToken(token));
    if (error) {
      return res
        .status(401)
        .send({ message: "Unauthorized: " + error.message });
    }

    return res.status(200).send({ message: "Logout successful" });
  } catch (error) {
    return res
      .status(500)
      .send({ message: "Internal Server Error: " + error.message });
  }
};

module.exports = async function deleteAdmin(req, res) {
  try {
    const authorization = req.headers.authorization;

    if (!authorization) {
      return res
        .status(401)
        .send({ message: "Unauthorized: No token provided" });
    }

    const [bearer, token] = authorization.split(" ");

    if (bearer !== "Bearer" || !token) {
      return res
        .status(401)
        .send({ message: "Unauthorized: Invalid token format" });
    }

    const [error, decodedToken] = await to(adminJwt.verifyaccessToken(token));
    if (error) {
      return res
        .status(401)
        .send({ message: "Unauthorized: " + error.message });
    }

    const adminIdFromToken = decodedToken.id;

    const [deleteError, deletedAdmin] = await to(
      Admin.destroy({ where: { id: adminIdFromToken } })
    );

    if (deleteError) {
      return res
        .status(500)
        .send({ message: "Failed to delete admin: " + deleteError.message });
    }

    if (!deletedAdmin) {
      return res
        .status(404)
        .send({ message: "Admin not found or already deleted" });
    }

    return res.status(200).send({ message: "Admin successfully deleted" });
  } catch (error) {
    return res
      .status(500)
      .send({ message: "Internal Server Error: " + error.message });
  }
};
