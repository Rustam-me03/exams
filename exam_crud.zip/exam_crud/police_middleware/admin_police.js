const { to } = require("../helpers/to_promise.js");
const adminJwt = require("../services/jwt_service");

module.exports = async (req, res, next) => {
  try {
    const authorization = req.headers.authorization;

    if (!authorization) {
      return res
        .status(403)
        .json({ message: "Admin not authorized (Token not found)" });
    }

    const [bearer, token] = authorization.split(" ");

    if (bearer !== "Bearer" || !token) {
      return res
        .status(403)
        .json({ message: "Admin not authorized (Invalid token format)" });
    }

    const [error, decodedToken] = await to(adminJwt.verifyaccessToken(token));
    if (error) {
      return res
        .status(403)
        .json({ message: "Invalid token: " + error.message });
    }

    req.admin = decodedToken; 
    next();
  } catch (error) {
    return res.status(500).json({ message: "Server error: " + error.message });
  }
};
