const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");

const Customers = sequelize.define(
  "Customers",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(255),
    },
    surname: {
      type: DataTypes.STRING,
    },
    email: { type: DataTypes.STRING },
    phone: { type: DataTypes.STRING },
    password: { type: DataTypes.STRING },
    address: { type: DataTypes.STRING },
    passport_number: { type: DataTypes.STRING(9) },
    refresh_token: { type: DataTypes.STRING },
    verification: { type: DataTypes.BOOLEAN },
    created_at: { type: DataTypes.TIME },
  },
  {
    freezeTableName: true,
    timestamps: true,
    createdAt: "created_date",
    updatedAt: "updated_date",
  }
);

module.exports = Customers;
