const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");

const Categories = sequelize.define("Categories", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  CategoryName: { type: DataTypes.STRING },
  CategoryDescription: { type: DataTypes.TEXT },
  parent_category_id: { type: DataTypes.BIGINT },
});

module.exports = Categories;
