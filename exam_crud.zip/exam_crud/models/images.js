const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");

const Images = sequelize.define("Images", {
  id: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  product_id: { type: DataTypes.BIGINT },
  img_url: { type: DataTypes.STRING },
  is_main: { type: DataTypes.BOOLEAN },
  upload_at: { type: DataTypes.DATE },
});

module.exports = Images;
