const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");

const Installments = sequelize.define("Installments", {
  id: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  DurationMonths: { type: DataTypes.INTEGER },
  Description: { type: DataTypes.TEXT },
  Interest_rate: { type: DataTypes.DECIMAL },
  created_at: { type: DataTypes.DATE },
  update_at: { type: DataTypes.DATE },
});

module.exports = Installments;
