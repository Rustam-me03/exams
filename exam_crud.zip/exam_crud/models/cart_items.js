const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");
const Carts = require("./carts");
const Products = require("./product");

const Cart_Items = sequelize.define("Cart_Items", {
  id: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  quantity: { type: DataTypes.INTEGER },
});

Cart_Items.belongsTo(Carts)
Cart_Items.belongsTo(Products)

Products.hasMany(Cart_Items)
Carts.hasMany(Cart_Items)

module.exports = Cart_Items;
