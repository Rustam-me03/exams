const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");

const Payments = sequelize.define("Payments", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  OrderID: { type: DataTypes.BIGINT },
  PaymentDate: { type: DataTypes.DATE },
  PaymentAmount: { type: DataTypes.DECIMAL },
  PaymentMethod: { type: DataTypes.STRING },
  status: { type: DataTypes.ENUM("paid", "pending") },
});

module.exports = Payments