const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");
const Customers = require("./customer");

const Carts = sequelize.define("Carts", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  OrderDate: { type: DataTypes.DATE },
});

Carts.belongsTo(Customers)
Customers.hasMany(Carts)

module.exports = Carts;
