const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");

const Product = sequelize.define("Product", {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  ProductName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Description: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  Price: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
  StockQuantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  CategoryID: {
    type: DataTypes.INTEGER,
  },
  AddedDate: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  Brand_id: {
    type: DataTypes.INTEGER,
  },
});

module.exports = Product;
