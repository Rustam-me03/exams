const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");

const Contract_Items = sequelize.define("Contract_Items", {
  id: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  contract_id: { type: DataTypes.BIGINT },
  product_id: { type: DataTypes.BIGINT },
  created_at: { type: DataTypes.DATE },
  updated_at: { type: DataTypes.DATE },
});

module.exports = Contract_Items;
