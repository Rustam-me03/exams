const sequelize = require("../config/db");
const { DataTypes } = require("sequelize");
const Admin = require("./admin");
const Installments = require("./installment");

const Contracts = sequelize.define("Contracts", {
  id: {
    type: DataTypes.BIGINT,
    primaryKey: true,
    autoIncrement: true,
  },
  customer_id: { type: DataTypes.BIGINT },
  admin_id: { type: DataTypes.BIGINT },
  start_date: { type: DataTypes.DATE },
  down_payment: { type: DataTypes.DECIMAL },
  status: { type: DataTypes.ENUM("active", "inactive") },
  total_amount: { type: DataTypes.DECIMAL },
  installments_id: { type: DataTypes.BIGINT },
});

Contracts.belongsTo(Admin);
Contracts.belongsTo(Installments);

Admin.hasMany(Contracts);
Installments.hasMany(Contracts);

module.exports = Contracts;
