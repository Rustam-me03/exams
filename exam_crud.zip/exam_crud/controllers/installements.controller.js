const Installment = require("../models/installment");
const { errorHandler } = require("../helpers/errorHandler");
const {
  validateInstallment,
  validateIdParam,
} = require("../validations/installment.js");

const calculateInstallmentDetails = (totalAmount, durationMonths) => {
  const downPaymentRate = 10; 
  let interestRate;

  if (durationMonths === 6) interestRate = 25;
  else if (durationMonths === 12) interestRate = 35;
  else if (durationMonths === 18) interestRate = 40;
  else throw new Error("Invalid DurationMonths. Allowed values: 6, 12, 18.");

  const downPayment = (totalAmount * downPaymentRate) / 100;
  const remainingAmount = totalAmount - downPayment;
  const totalInterest = (remainingAmount * interestRate) / 100;
  const totalPayable = remainingAmount + totalInterest;
  const monthlyInstallment = totalPayable / durationMonths;

  return {
    downPayment,
    interestRate,
    totalInterest,
    totalPayable,
    monthlyInstallment,
  };
};

const createInstallment = async (req, res) => {
  const { totalAmount, DurationMonths, Description } = req.body;

  const { error } = validateInstallment(req.body);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  try {
    const installmentDetails = calculateInstallmentDetails(
      totalAmount,
      DurationMonths
    );

    const newInstallment = new Installment({
      totalAmount,
      DurationMonths,
      Description,
      downPayment: installmentDetails.downPayment,
      interestRate: installmentDetails.interestRate,
      totalPayable: installmentDetails.totalPayable,
      monthlyInstallment: installmentDetails.monthlyInstallment,
      created_at: new Date(),
      updated_at: new Date(),
    });

    await newInstallment.save();
    res.status(201).json(newInstallment);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getAllInstallments = async (req, res) => {
  try {
    const installments = await Installment.findAll();
    res.status(200).json(installments);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getInstallmentById = async (req, res) => {
  const { error } = validateIdParam(req.params);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  try {
    const installment = await Installment.findById(req.params.id);
    if (!installment) {
      return res.status(404).json({ message: "Installment not found" });
    }
    res.status(200).json(installment);
  } catch (error) {
    errorHandler(error, res);
  }
};

const updateInstallment = async (req, res) => {
  const { totalAmount, DurationMonths, Description } = req.body;

  const { error } = validateInstallment(req.body);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  const { error: idError } = validateIdParam(req.params);
  if (idError) {
    return res
      .status(400)
      .json({ message: idError.details.map((e) => e.message).join(", ") });
  }

  try {
    // Calculate installment details
    const installmentDetails = calculateInstallmentDetails(
      totalAmount,
      DurationMonths
    );

    const updatedInstallment = await Installment.findByIdAndUpdate(
      req.params.id,
      {
        totalAmount,
        DurationMonths,
        Description,
        downPayment: installmentDetails.downPayment,
        interestRate: installmentDetails.interestRate,
        totalPayable: installmentDetails.totalPayable,
        monthlyInstallment: installmentDetails.monthlyInstallment,
        updated_at: new Date(),
      },
      { new: true }
    );

    if (!updatedInstallment) {
      return res.status(404).json({ message: "Installment not found" });
    }
    res.status(200).json(updatedInstallment);
  } catch (error) {
    errorHandler(error, res);
  }
};

const deleteInstallment = async (req, res) => {
  const { error } = validateIdParam(req.params);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  try {
    const deletedInstallment = await Installment.findByIdAndDelete(
      req.params.id
    );
    if (!deletedInstallment) {
      return res.status(404).json({ message: "Installment not found" });
    }
    res.status(200).json({ message: "Installment deleted successfully" });
  } catch (error) {
    errorHandler(error, res);
  }
};

module.exports = {
  createInstallment,
  getAllInstallments,
  getInstallmentById,
  updateInstallment,
  deleteInstallment,
};
