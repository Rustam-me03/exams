const { errorHandler } = require("../helpers/errorHandler");
const Brand = require("../models/brand");
const {
  validateAddBrand,
  validateUpdateBrand,
  validateIdParam,
} = require("../validations/brand");

const addBrand = async (req, res) => {
  const { error } = validateAddBrand(req.body);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  try {
    const { name } = req.body;

    const existingBrand = await Brand.findOne({ where: { name } });
    if (existingBrand) {
      return res.status(400).json({ message: "This brand already exists." });
    }

    const newBrand = await Brand.create({ name });
    res.status(201).json({ message: "New brand added.", newBrand });
  } catch (error) {
    errorHandler(error, res);
  }
};

const updateBrandById = async (req, res) => {
  const { error: paramError } = validateIdParam(req.params);
  if (paramError) {
    return res
      .status(400)
      .json({ message: paramError.details.map((e) => e.message).join(", ") });
  }

  const { error: bodyError } = validateUpdateBrand(req.body);
  if (bodyError) {
    return res
      .status(400)
      .json({ message: bodyError.details.map((e) => e.message).join(", ") });
  }

  try {
    const { id } = req.params;
    const { name } = req.body;

    const brand = await Brand.findByPk(id);
    if (!brand) {
      return res.status(404).json({ message: "Brand not found." });
    }

    await brand.update({ name: name || brand.name });
    res.status(200).json({ message: "Brand updated successfully.", brand });
  } catch (error) {
    errorHandler(error, res);
  }
};

const getBrandById = async (req, res) => {
  const { error } = validateIdParam(req.params);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  try {
    const { id } = req.params;
    const brand = await Brand.findByPk(id);

    if (!brand) {
      return res.status(404).json({ message: "Brand not found." });
    }

    res.status(200).json(brand);
  } catch (error) {
    errorHandler(error, res);
  }
};

const deleteBrandById = async (req, res) => {
  const { error } = validateIdParam(req.params);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  try {
    const { id } = req.params;
    const brand = await Brand.destroy({ where: { id } });

    if (!brand) {
      return res.status(404).json({ message: "Brand not found." });
    }

    res.status(200).json({ message: "Brand deleted successfully." });
  } catch (error) {
    errorHandler(error, res);
  }
};

const getBrands = async (req, res) => {
  try {
    const brands = await Brand.findAll();
    res.status(200).json(brands);
  } catch (error) {
    errorHandler(error, res);
  }
};

module.exports = {
  addBrand,
  getBrands,
  deleteBrandById,
  updateBrandById,
  getBrandById,
};
