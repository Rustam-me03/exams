const Images = require("../models/images");
const { validateImage, validateIdParam } = require("../validations/images");
const errorHandler = require("../helpers/errorHandler");

const createImg = async (req, res) => {
  const { name, path, size, type } = req.body;

  const { error } = validateImage.validate({ name, path, size, type });
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const newImage = await Images.create({ name, path, size, type });
    res.status(201).json(newImage);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getImgs = async (req, res) => {
  try {
    const images = await Images.findAll();
    res.status(200).json(images);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getImgById = async (req, res) => {
  const { id } = req.params;

  const { error } = validateIdParam.validate({ id });
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const image = await Images.findByPk(id);
    if (!image) {
      return res.status(404).json({ message: "Image not found" });
    }
    res.status(200).json(image);
  } catch (error) {
    errorHandler(error, res);
  }
};

const updateImg = async (req, res) => {
  const { id } = req.params;
  const { name, path, size, type } = req.body;

  const { error } = validateIdParam.validate({ id });
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const image = await Images.findByPk(id);
    if (!image) {
      return res.status(404).json({ message: "Image not found" });
    }

    image.name = name || image.name;
    image.path = path || image.path;
    image.size = size || image.size;
    image.type = type || image.type;
    image.updated_at = new Date();

    await image.save();
    res.status(200).json({ message: "Image updated successfully" });
  } catch (error) {
    errorHandler(error, res);
  }
};

const deleteImg = async (req, res) => {
  const { id } = req.params;

  const { error } = validateIdParam.validate({ id });
  if (error) return res.status(400).json({ message: error.details[0].message });

  try {
    const image = await Images.findByPk(id);
    if (!image) {
      return res.status(404).json({ message: "Image not found" });
    }

    await image.destroy();
    res.status(200).json({ message: "Image deleted successfully" });
  } catch (error) {
    errorHandler(error, res);
  }
};

module.exports = {
  createImg,
  getImgs,
  getImgById,
  updateImg,
  deleteImg,
};
