const {
  validateContract,
  validateIdParam,
} = require("../validations/contractItems");
const ContractItem = require("../models/contract_items");

const createContractItem = async (req, res) => {
  const { error } = validateContract.validate(req.body);
  if (error) {
    return res.status(400).json({
      errors: error.details.map((detail) => detail.message),
    });
  }

  const { contract_id, product_id } = req.body;

  try {
    const newItem = await ContractItem.create({ contract_id, product_id });
    res.status(201).json(newItem);
  } catch (error) {
    res.status(500).json({ error: "Failed to create contract item" });
  }
};

const getContractItems = async (req, res) => {
  try {
    const items = await ContractItem.findAll();
    res.status(200).json(items);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch contract items" });
  }
};

const getContractItemById = async (req, res) => {
  const { error } = validateIdParam.validate(req.params);
  if (error) {
    return res.status(400).json({
      errors: error.details.map((detail) => detail.message),
    });
  }

  const { id } = req.params;

  try {
    const item = await ContractItem.findByPk(id);
    if (!item) {
      return res.status(404).json({ error: "Contract item not found" });
    }
    res.status(200).json(item);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch contract item" });
  }
};

const updateContractItem = async (req, res) => {
  const { error: idError } = validateIdParam.validate(req.params);
  if (idError) {
    return res.status(400).json({
      errors: idError.details.map((detail) => detail.message),
    });
  }

  const { error: bodyError } = validateContract.validate(req.body);
  if (bodyError) {
    return res.status(400).json({
      errors: bodyError.details.map((detail) => detail.message),
    });
  }

  const { id } = req.params;
  const { contract_id, product_id } = req.body;

  try {
    const item = await ContractItem.findByPk(id);
    if (!item) {
      return res.status(404).json({ error: "Contract item not found" });
    }

    item.contract_id = contract_id || item.contract_id;
    item.product_id = product_id || item.product_id;
    item.updated_at = new Date();

    await item.save();
    res.status(200).json(item);
  } catch (error) {
    res.status(500).json({ error: "Failed to update contract item" });
  }
};

const deleteContractItem = async (req, res) => {
  const { error } = validateIdParam.validate(req.params);
  if (error) {
    return res.status(400).json({
      errors: error.details.map((detail) => detail.message),
    });
  }

  const { id } = req.params;

  try {
    const item = await ContractItem.findByPk(id);
    if (!item) {
      return res.status(404).json({ error: "Contract item not found" });
    }

    await item.destroy();
    res.status(200).json({ message: "Contract item deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete contract item" });
  }
};

module.exports = {
  createContractItem,
  getContractItems,
  getContractItemById,
  updateContractItem,
  deleteContractItem,
};
