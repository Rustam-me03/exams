const Product = require("../models/product");
const { validateProduct, validateIdParam } = require("../validations/product");
const { errorHandler } = require("../helpers/errorHandler");

const createProduct = async (req, res) => {
  const { name, description, price, stock } = req.body;

  const { error } = validateProduct(req.body);
  if (error) {
    return res.status(400).json({ message: error.details[0].message });
  }

  try {
    const newProduct = await Product.create({
      name,
      description,
      price,
      stock,
    });
    res.status(201).json(newProduct);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getProducts = async (req, res) => {
  try {
    const products = await Product.findAll();
    res.status(200).json(products);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getProductById = async (req, res) => {
  const { id } = req.params;

  const { error } = validateIdParam(req.params);
  if (error) {
    return res.status(400).json({ message: error.details[0].message });
  }

  try {
    const product = await Product.findByPk(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.status(200).json(product);
  } catch (error) {
    errorHandler(error, res);
  }
};

const updateProduct = async (req, res) => {
  const { id } = req.params;
  const { name, description, price, stock } = req.body;

  const { error } = validateIdParam(req.params);
  if (error) {
    return res.status(400).json({ message: error.details[0].message });
  }

  const productValidation = validateProduct(req.body);
  if (productValidation.error) {
    return res
      .status(400)
      .json({ message: productValidation.error.details[0].message });
  }

  try {
    const product = await Product.findByPk(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    product.name = name || product.name;
    product.description = description || product.description;
    product.price = price || product.price;
    product.stock = stock || product.stock;
    product.updated_at = new Date();

    await product.save();
    res.status(200).json({ message: "Product updated successfully" });
  } catch (error) {
    errorHandler(error, res);
  }
};

const deleteProduct = async (req, res) => {
  const { id } = req.params;

  const { error } = validateIdParam(req.params);
  if (error) {
    return res.status(400).json({ message: error.details[0].message });
  }

  try {
    const product = await Product.findByPk(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    await product.destroy();
    res.status(200).json({ message: "Product deleted successfully" });
  } catch (error) {
    errorHandler(error, res);
  }
};

module.exports = {
  createProduct,
  getProducts,
  getProductById,
  updateProduct,
  deleteProduct,
};
