const Feedback = require("../models/feedback");
const {
  validateFeedback,
  validateIdParam,
} = require("../validations/feedback");
const errorHandler = require("../helpers/errorHandler");

const createFeedback = async (req, res) => {
  const { user_id, message, rating } = req.body;

  try {
    const newFeedback = await Feedback.create({ user_id, message, rating });
    res.status(201).json(newFeedback);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getFeedbacks = async (req, res) => {
  try {
    const feedbacks = await Feedback.findAll();
    res.status(200).json(feedbacks);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getFeedbackById = async (req, res) => {
  const { id } = req.params;

  try {
    const feedback = await Feedback.findByPk(id);
    if (!feedback) {
      return res.status(404).json({ message: "Feedback not found" });
    }
    res.status(200).json(feedback);
  } catch (error) {
    errorHandler(error, res);
  }
};

const updateFeedback = async (req, res) => {
  const { id } = req.params;
  const { user_id, message, rating } = req.body;

  try {
    const feedback = await Feedback.findByPk(id);
    if (!feedback) {
      return res.status(404).json({ message: "Feedback not found" });
    }

    feedback.user_id = user_id || feedback.user_id;
    feedback.message = message || feedback.message;
    feedback.rating = rating || feedback.rating;
    feedback.updated_at = new Date();

    await feedback.save();
    res.status(200).json({ message: "Feedback updated successfully" });
  } catch (error) {
    errorHandler(error, res);
  }
};

const deleteFeedback = async (req, res) => {
  const { id } = req.params;

  try {
    const feedback = await Feedback.findByPk(id);
    if (!feedback) {
      return res.status(404).json({ message: "Feedback not found" });
    }

    await feedback.destroy();
    res.status(200).json({ message: "Feedback deleted successfully" });
  } catch (error) {
    errorHandler(error, res);
  }
};

module.exports = {
  createFeedback,
  getFeedbacks,
  getFeedbackById,
  updateFeedback,
  deleteFeedback,
};
