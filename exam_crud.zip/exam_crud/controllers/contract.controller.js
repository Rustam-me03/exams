const {
  validateContract,
  validateIdParam,
} = require("../validations/contract");
const Contracts = require("../models/contracts");

const createContract = async (req, res) => {
  const { error } = validateContract(req);
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((detail) => detail.message) });
  }

  const {
    customer_id,
    admin_id,
    start_date,
    down_payment,
    status,
    total_amount,
    installments_id,
  } = req.body;

  try {
    const newContract = await Contracts.create({
      customer_id,
      admin_id,
      start_date,
      down_payment,
      status,
      total_amount,
      installments_id,
    });
    res.status(201).json(newContract);
  } catch (error) {
    res.status(500).json({ error: "Failed to create contract" });
  }
};

const getContracts = async (req, res) => {
  try {
    const contracts = await Contracts.findAll();
    res.status(200).json(contracts);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch contracts" });
  }
};

const getContractById = async (req, res) => {
  const { error } = validateIdParam(req);
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((detail) => detail.message) });
  }

  const { id } = req.params;

  try {
    const contract = await Contracts.findByPk(id);
    if (!contract) {
      return res.status(404).json({ error: "Contract not found" });
    }
    res.status(200).json(contract);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch contract" });
  }
};

const updateContract = async (req, res) => {
  const idError = validateIdParam(req);
  if (idError?.error) {
    return res
      .status(400)
      .json({ errors: idError.error.details.map((detail) => detail.message) });
  }

  const bodyError = validateContract(req);
  if (bodyError?.error) {
    return res.status(400).json({
      errors: bodyError.error.details.map((detail) => detail.message),
    });
  }

  const { id } = req.params;
  const {
    customer_id,
    admin_id,
    start_date,
    down_payment,
    status,
    total_amount,
    installments_id,
  } = req.body;

  try {
    const contract = await Contracts.findByPk(id);
    if (!contract) {
      return res.status(404).json({ error: "Contract not found" });
    }

    contract.customer_id = customer_id;
    contract.admin_id = admin_id;
    contract.start_date = start_date;
    contract.down_payment = down_payment;
    contract.status = status;
    contract.total_amount = total_amount;
    contract.installments_id = installments_id;
    contract.updated_at = new Date();

    await contract.save();
    res.status(200).json(contract);
  } catch (error) {
    res.status(500).json({ error: "Failed to update contract" });
  }
};

const deleteContract = async (req, res) => {
  const { error } = validateIdParam(req);
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((detail) => detail.message) });
  }

  const { id } = req.params;

  try {
    const contract = await Contracts.findByPk(id);
    if (!contract) {
      return res.status(404).json({ error: "Contract not found" });
    }

    await contract.destroy();
    res.status(200).json({ message: "Contract deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete contract" });
  }
};

module.exports = {
  createContract,
  getContracts,
  getContractById,
  updateContract,
  deleteContract,
};
