const { errorHandler } = require("../helpers/errorHandler");
const Admin = require("../models/admin");
const bcrypt = require("bcrypt");
const jwtService = require("../services/jwt_service");
const {
  adminSchema,
  loginSchema,
  updateAdminSchema,
} = require("../validations/admin");

const hashPassword = async (password) => {
  const saltRounds = 10;
  return await bcrypt.hash(password, saltRounds);
};

const addAdmin = async (req, res) => {
  try {
    const { error } = adminSchema.validate(req.body);
    if (error)
      return res.status(400).json({ message: error.details[0].message });

    const {
      name,
      surename,
      username,
      email,
      phone_number,
      password,
      isActive,
      isCreator,
    } = req.body;

    const existingAdmin = await Admin.findOne({ where: { email } });
    if (existingAdmin)
      return res.status(400).json({ message: "This admin already exists" });

    const hashedPassword = await hashPassword(password);
    const newAdmin = await Admin.create({
      name,
      surename,
      username,
      email,
      phone_number,
      password: hashedPassword,
      isActive,
      isCreator,
    });

    res.status(201).json({ message: "New admin added", newAdmin });
  } catch (error) {
    errorHandler(error, res);
  }
};

const loginAdmin = async (req, res) => {
  try {
    const { error } = loginSchema.validate(req.body);
    if (error)
      return res.status(400).json({ message: error.details[0].message });

    const { email, password } = req.body;
    const admin = await Admin.findOne({ where: { email } });
    if (!admin)
      return res.status(401).json({ message: "Invalid email or password" });

    const validPassword = await bcrypt.compare(password, admin.password);
    if (!validPassword)
      return res.status(401).json({ message: "Invalid email or password" });

    const payload = {
      id: admin.id,
      name: admin.name,
      surename: admin.surename,
      username: admin.username,
      email: admin.email,
      phone_number: admin.phone_number,
      isActive: admin.isActive,
      isCreator: admin.isCreator,
    };

    const tokens = jwtService.generateTokens(payload);
    admin.refresh_token = tokens.refreshToken;
    await admin.save();

    res.cookie("admin_refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: process.env.REFRESH_TOKEN_MS,
    });

    res
      .status(200)
      .json({ message: "Welcome", accessToken: tokens.accessToken });
  } catch (error) {
    errorHandler(error, res);
  }
};

const logoutAdmin = async (req, res) => {
  try {
    const { admin_refreshToken } = req.cookies;
    if (!admin_refreshToken)
      return res.status(400).json({ message: "Token not found" });

    const admin = await Admin.findOne({
      where: { refresh_token: admin_refreshToken },
    });
    if (!admin)
      return res
        .status(400)
        .json({ message: "No admin found with this token" });

    await admin.update({ refresh_token: null });
    res.clearCookie("admin_refreshToken");

    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    errorHandler(error, res);
  }
};

const refreshAdminToken = async (req, res) => {
  try {
    const { admin_refreshToken } = req.cookies;
    if (!admin_refreshToken)
      return res.status(400).json({ message: "Token not found" });

    const admin = await Admin.findOne({
      where: { refresh_token: admin_refreshToken },
    });
    if (!admin) return res.status(404).json({ message: "Admin not found" });

    const payload = {
      id: admin.id,
      name: admin.name,
      surename: admin.surename,
      username: admin.username,
      email: admin.email,
      phone_number: admin.phone_number,
      isActive: admin.isActive,
      isCreator: admin.isCreator,
    };

    const tokens = jwtService.generateTokens(payload);
    await admin.update({ refresh_token: tokens.refreshToken });

    res.cookie("admin_refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: process.env.REFRESH_TOKEN_MS,
    });

    res
      .status(200)
      .json({ message: "Token refreshed", accessToken: tokens.accessToken });
  } catch (error) {
    errorHandler(error, res);
  }
};

const getAdmins = async (req, res) => {
  try {
    const admins = await Admin.findAll();
    res.status(200).json(admins);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getAdminById = async (req, res) => {
  try {
    const { id } = req.params;
    const admin = await Admin.findByPk(id);
    if (!admin) return res.status(404).json({ message: "Admin not found" });

    res.status(200).json(admin);
  } catch (error) {
    errorHandler(error, res);
  }
};

const updateAdminById = async (req, res) => {
  try {
    const { error } = updateAdminSchema.validate(req.body);
    if (error)
      return res.status(400).json({ message: error.details[0].message });

    const { id } = req.params;
    const {
      name,
      surename,
      username,
      email,
      phone_number,
      password,
      isActive,
      isCreator,
    } = req.body;

    const admin = await Admin.findByPk(id);
    if (!admin) return res.status(404).json({ message: "Admin not found" });

    const hashedPassword = password
      ? await hashPassword(password)
      : admin.password;

    await admin.update({
      name: name || admin.name,
      surename: surename || admin.surename,
      username: username || admin.username,
      email: email || admin.email,
      phone_number: phone_number || admin.phone_number,
      password: hashedPassword,
      isActive: isActive ?? admin.isActive,
      isCreator: isCreator ?? admin.isCreator,
    });

    res.status(200).json({ message: "Admin updated successfully", admin });
  } catch (error) {
    errorHandler(error, res);
  }
};

const deleteAdminById = async (req, res) => {
  try {
    const { id } = req.params;

    const admin = await Admin.findByPk(id);
    if (!admin) return res.status(404).json({ message: "Admin not found" });

    await admin.destroy();

    res.status(200).json({ message: "Admin deleted successfully", admin });
  } catch (error) {
    errorHandler(error, res);
  }
};

module.exports = {
  addAdmin,
  loginAdmin,
  logoutAdmin,
  refreshAdminToken,
  getAdmins,
  getAdminById,
  updateAdminById,
  deleteAdminById,
};
