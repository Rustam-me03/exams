const { validatePayment, validateIdParam } = require("../validations/payments");
const Payments = require("../models/Payments");

const createPayment = async (req, res) => {
  const { error } = validatePayment(req);
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((detail) => detail.message) });
  }

  const { OrderID, PaymentDate, PaymentAmount, PaymentMethod, status } =
    req.body;

  try {
    const newPayment = await Payments.create({
      OrderID,
      PaymentDate,
      PaymentAmount,
      PaymentMethod,
      status,
    });
    res.status(201).json(newPayment);
  } catch (error) {
    res.status(500).json({ error: "Failed to create payment" });
  }
};

const getPayments = async (req, res) => {
  try {
    const payments = await Payments.findAll();
    res.status(200).json(payments);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch payments" });
  }
};

const getPaymentById = async (req, res) => {
  const { error } = validateIdParam(req);
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((detail) => detail.message) });
  }

  const { id } = req.params;

  try {
    const payment = await Payments.findByPk(id);
    if (!payment) {
      return res.status(404).json({ error: "Payment not found" });
    }
    res.status(200).json(payment);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch payment" });
  }
};

const updatePayment = async (req, res) => {
  const idError = validateIdParam(req);
  if (idError?.error) {
    return res
      .status(400)
      .json({ errors: idError.error.details.map((detail) => detail.message) });
  }

  const bodyError = validatePayment(req);
  if (bodyError?.error) {
    return res
      .status(400)
      .json({
        errors: bodyError.error.details.map((detail) => detail.message),
      });
  }

  const { id } = req.params;
  const { OrderID, PaymentDate, PaymentAmount, PaymentMethod, status } =
    req.body;

  try {
    const payment = await Payments.findByPk(id);
    if (!payment) {
      return res.status(404).json({ error: "Payment not found" });
    }

    payment.OrderID = OrderID || payment.OrderID;
    payment.PaymentDate = PaymentDate || payment.PaymentDate;
    payment.PaymentAmount = PaymentAmount || payment.PaymentAmount;
    payment.PaymentMethod = PaymentMethod || payment.PaymentMethod;
    payment.status = status || payment.status;
    payment.updatedAt = new Date();

    await payment.save();
    res.status(200).json(payment);
  } catch (error) {
    res.status(500).json({ error: "Failed to update payment" });
  }
};

const deletePayment = async (req, res) => {
  const { error } = validateIdParam(req);
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((detail) => detail.message) });
  }

  const { id } = req.params;

  try {
    const payment = await Payments.findByPk(id);
    if (!payment) {
      return res.status(404).json({ error: "Payment not found" });
    }

    await payment.destroy();
    res.status(200).json({ message: "Payment deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete payment" });
  }
};

module.exports = {
  createPayment,
  getPayments,
  getPaymentById,
  updatePayment,
  deletePayment,
};
