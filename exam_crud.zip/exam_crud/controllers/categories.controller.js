const Categories = require("../models/categories.model");
const {
  validateCategory,
  validateIdParam,
} = require("../validations/category");

const createCategory = async (req, res) => {
  const { error } = validateCategory(req.body);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  try {
    const category = await Categories.create(req.body);
    res.status(201).json({
      message: "Category created successfully",
      category,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to create category", error: error.message });
  }
};

const getAllCategories = async (req, res) => {
  try {
    const categories = await Categories.findAll();
    res.status(200).json(categories);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to retrieve categories", error: error.message });
  }
};

const getCategoryById = async (req, res) => {
  const { error } = validateIdParam(req.params);
  if (error) {
    return res
      .status(400)
      .json({ message: error.details.map((e) => e.message).join(", ") });
  }

  try {
    const category = await Categories.findByPk(req.params.id);
    if (category) {
      res.status(200).json(category);
    } else {
      res.status(404).json({ message: "Category not found" });
    }
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to retrieve category", error: error.message });
  }
};

const updateCategory = async (req, res) => {
  const { error: bodyError } = validateCategory(req.body);
  const { error: idError } = validateIdParam(req.params);

  if (bodyError || idError) {
    const messages = [
      ...(bodyError ? bodyError.details.map((e) => e.message) : []),
      ...(idError ? idError.details.map((e) => e.message) : []),
    ];
    return res.status(400).json({ message: messages.join(", ") });
  }

  try {
    const [updated] = await Categories.update(req.body, {
      where: { id: req.params.id },
    });
    if (updated) {
      const updatedCategory = await Categories.findByPk(req.params.id);
      res.status(200).json({
        message: "Category updated successfully",
        category: updatedCategory,
      });
    } else {
      res.status(404).json({ message: "Category not found" });
    }
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to update category", error: error.message });
  }
};

module.exports = {
  createCategory,
  getAllCategories,
  getCategoryById,
  updateCategory,
};
