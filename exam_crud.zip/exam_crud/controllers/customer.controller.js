const { errorHandler } = require("../helpers/errorHandler");
const Customer = require("../models/customer");
const bcrypt = require("bcrypt");
const jwtService = require("../services/jwt_service");

const hashPassword = async (password) => {
  const saltRounds = 10;
  return await bcrypt.hash(password, saltRounds);
};

const addCustomer = async (req, res) => {
  const {
    name,
    surname,
    email,
    phone_number,
    password,
    passport_number,
    verification,
    isActive,
  } = req.body;

  try {
    const existingCustomer = await Customer.findOne({ where: { email } });
    if (existingCustomer) {
      return res.status(400).json({ message: "This customer already exists" });
    }

    const hashedPassword = await hashPassword(password);
    const newCustomer = await Customer.create({
      name,
      surname,
      email,
      phone_number,
      password: hashedPassword,
      passport_number,
      verification,
      isActive,
    });

    res.status(201).json({ message: "New customer added", newCustomer });
  } catch (error) {
    errorHandler(error, res);
  }
};

// Логин клиента
const loginCustomer = async (req, res) => {
  const { email, password } = req.body;

  try {
    const customer = await Customer.findOne({ where: { email } });

    if (!customer) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const validPassword = await bcrypt.compare(password, customer.password);
    if (!validPassword) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const payload = {
      id: customer.id,
      name: customer.name,
      surname: customer.surname,
      email: customer.email,
      phone_number: customer.phone_number,
      isActive: customer.isActive,
    };

    const tokens = jwtService.generateTokens(payload);
    await customer.update({ refreshToken: tokens.refreshToken });

    const maxAge = parseInt(process.env.REFRESH_TOKEN_MS, 10) || 604800000; // По умолчанию 7 дней

    res.cookie("customer_refreshToken", tokens.refreshToken, {
      httpOnly: true, // Доступен только через HTTP
      secure: process.env.NODE_ENV === "production", // Только HTTPS в продакшене
      sameSite: "strict", // Установка политики для предотвращения CSRF
      maxAge: maxAge, // Преобразованное значение времени жизни
    });

    res.status(200).json({
      message: "Welcome",
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    });
  } catch (error) {
    errorHandler(error, res);
  }
};

const logoutCustomer = async (req, res) => {
  try {
    const { customer_refreshToken } = req.cookies;

    if (!customer_refreshToken) {
      return res.status(400).json({ message: "Token not found" });
    }

    const customer = await Customer.findOne({
      where: { refreshToken: customer_refreshToken },
    });
    if (!customer) {
      return res
        .status(400)
        .json({ message: "No customer found with this token" });
    }

    await customer.update({ refreshToken: null });
    res.clearCookie("customer_refreshToken");

    res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    errorHandler(error, res);
  }
};

// Обновить клиента по ID
const updateCustomerById = async (req, res) => {
  const { id } = req.params;
  const { name, surname, email, phone_number, password, isActive } = req.body;

  try {
    const customer = await Customer.findByPk(id);
    if (!customer) {
      return res.status(404).json({ message: "Customer not found" });
    }

    const hashedPassword = password
      ? await hashPassword(password)
      : customer.password;

    await customer.update({
      name: name || customer.name,
      surname: surname || customer.surname,
      email: email || customer.email,
      phone_number: phone_number || customer.phone_number,
      password: hashedPassword,
      isActive: isActive ?? customer.isActive,
    });

    res
      .status(200)
      .json({ message: "Customer updated successfully", customer });
  } catch (error) {
    errorHandler(error, res);
  }
};

const getCustomers = async (req, res) => {
  try {
    const customers = await Customer.findAll();
    res.status(200).json(customers);
  } catch (error) {
    errorHandler(error, res);
  }
};

const getCustomerById = async (req, res) => {
  const { id } = req.params;

  try {
    const customer = await Customer.findByPk(id);

    if (!customer) {
      return res.status(404).json({ message: "Customer not found" });
    }

    res.status(200).json(customer);
  } catch (error) {
    errorHandler(error, res);
  }
};

const deleteCustomerById = async (req, res) => {
  try {
    const { id } = req.params;
    const customer = await Customer.destroy({ where: { id } });

    if (!customer) {
      return res.status(404).json({ message: "Customer not found" });
    }

    res.status(200).json({ message: "Customer deleted successfully" });
  } catch (error) {
    errorHandler(error, res);
  }
};

// Обновить refreshToken клиента
const refreshCustomerToken = async (req, res) => {
  try {
    const { customer_refreshToken } = req.cookies;

    if (!customer_refreshToken) {
      return res.status(400).json({ message: "Token not found" });
    }

    const customer = await Customer.findOne({
      where: { refreshToken: customer_refreshToken },
    });

    if (!customer) {
      return res.status(404).json({ message: "Customer not found" });
    }

    const payload = {
      id: customer.id,
      name: customer.name,
      surname: customer.surname,
      email: customer.email,
      phone_number: customer.phone_number,
      isActive: customer.isActive,
    };

    const tokens = jwtService.generateTokens(payload);

    await customer.update({ refreshToken: tokens.refreshToken });

    res.cookie("customer_refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: process.env.REFRESH_TOKEN_MS,
    });

    res.status(200).json({
      message: "Token refreshed",
      accessToken: tokens.accessToken,
    });
  } catch (error) {
    errorHandler(error, res);
  }
};

module.exports = {
  addCustomer,
  loginCustomer,
  logoutCustomer,
  refreshCustomerToken,
  getCustomers,
  deleteCustomerById,
  updateCustomerById,
  getCustomerById,
};
